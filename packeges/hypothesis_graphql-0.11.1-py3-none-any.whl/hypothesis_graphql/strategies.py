from ._strategies.strategy import from_schema, mutations, queries  # noqa: F401

# Backward compatibility
query = queries
